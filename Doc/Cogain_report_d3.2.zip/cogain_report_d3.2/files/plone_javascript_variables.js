// Global Plone variables that need to be accessible to the Javascripts

portal_url = 'http://www.cogain.org';
