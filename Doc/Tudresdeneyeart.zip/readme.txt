EyeArt Read Me


Copyright and Conditions of use
-------------------------------
Copyright (c) 2007: 
Technical University of Dresden, Applied Cognitive Research Unit, 
by Andre Meyer and Markus Dittmar.

EyeArt is freely available for personal use by people with disabilities. 
You may download and use it at your own risk. COGAIN or the developers 
will not be responsible for any possible damages caused by the EyeArt 
program. The program is distributed as it is. Unfortunately, we do not 
have resources to provide support or assist with any technical problems 
that may occur. However, if you have any comments or want to report bugs, 
feel free to email us at eyeart@cogain.org.

You are also free to use EyeArt for research and for eye-control related 
demonstration purposes as long as the copyright owners are acknowledged.

EyeArt is distributed by the COGAIN Network of Excellence's web portal at 
http://www.cogain.org/downloads/leisure-applications/eyeart/


EyeArt installation packet contents
-----------------------------------

EyeArt.exe -- main executable, double click this to start the program

EyeArt.ini -- setup file

EyeHelp.exe -- help used inside the program (does not work separately) 

Help (folder) -- help files (used by the program's help function)

EyeArt_Documentation.pdf  --  brief documentation
 (please note that video files mentioned in the documentation are not 
  included in this download packet because of their large file sizes) 

readme.txt  --  this file

Please do not remove or change any of the files.


Starting the application
------------------------
To start the application, there are two possibilities.

a) If you haven�t got the opportunity to start the main program after 
a calibration progress, simply double click the file EyeArt.exe in your 
main application folder. A tutor has to start and help you with the used 
eye tracker. After the calibration process, the program to move the mouse, 
have to be started, so you can use the mouse to interact with the system.

b) If the calibration and mouse control program enables you to start 
the application automatically, a tutor can enter the path and filename 
of the main application EyeArt.exe so it can be started following 
the calibration process.


How to draw
-----------
To draw a special shape you have to select it from the tool box on 
the left side and follow the instruction specified for this shape or object.

In general drawing a shape consists of two clicks (activation processes). 
You have either to decide the centre point and the radius or you have to 
decide two opposite edges. In both cases you do so by fixate these two 
points. Sometimes it is necessary to determine more than two points to draw. 
This is the case when drawing a polygon or a poly line. To use objects 
another routine will be used. For more information check the help page 
for the specific object. The shapes can be positioned everywhere on 
the drawing grid. The raster will help to fixate the accurate position.

An example video demonstrating basic drawing operations is available at
http://www.cogain.org/downloads/leisure-applications/eyeart/

Getting help/Further information
--------------------------------
EyeArt has an integrated help system which can be accessed by the main menu 
on the top of the application. In the help system you can either get help 
by using the content in a hierarchical way, by using the questioning system 
or by searching with a special keyword.




