Puzzle (c) 2006 Vytautas Vysniauskas, Siauliai University, Lithuania. 

Installation:
-------------
Download the zip-packet and uncompress the files into any folder. Start the program by selecting puzzle.exe. 

What to do?
-----------
The original picture is divided into rectangle pieces and shuffled. Your task is to put the puzzle pieces back into their right places.

How to play?
------------
First of all, you must load an image to play with. The program supports various image formats (jpg, jpeg, gif, bmp, png, tif, tiff, wmf). When an image is loaded, it will be shown on the screen. In the top left corner, there is an icon with eye. Move the cursor on and out of this icon to start the game. Remember that you can look at the original picture and back to the game by moving the cursor on and out of the top left piece.

After loading the picture, you can start playing the game. When you move the cursor, the current puzzle piece is marked with a rectangle surrounding the piece. If you stay in this rectangle more than a particular time, a 'clip' button will spring on the right or left side of the button. If you move the cursor on this button and keep it there for a while, the button will be pressed and the puzzle piece will be marked with black dashed rectangle. Now, when you move the cursor to another puzzle piece and stay there, two buttons will spring up. One button is for swapping the clipped puzzle piece with the current one, and another button can clip the current puzzle piece and release the previous one.

You can change some game options via the Options menu. Don't forget to reload the image after changing options.

Conditions of use:
------------------
Puzzle is freely available for personal use by people with disabilities. You may download and use it at your own risk. COGAIN or the developers will not be responsible for any possible damages caused by the program. The program is distributed as it is. We do not have resources to provide support or assist with any technical problems that may occur. However, if you have any comments or want to report bugs, feel free to email us at puzzle@cogain.org.

The Puzzle is available via the COGAIN Network of Excellence's web portal at http://www.cogain.org/downloads/leisure-applications/puzzle

Contents of the installation packet:
------------------------------------
- puzzle.exe -- game executable
- puzzle.ini -- setup file
- readme.txt -- this file
- a couple of example images (*.jpg)

The example pictures found in the download packet are included by courtesy of Niina Majaranta. You can replace them by your own pictures; simply delete the example images and put your own pictures in the game folder.

Puzzle (c) 2006 Vytautas Vysniauskas, Siauliai University, Lithuania. 
