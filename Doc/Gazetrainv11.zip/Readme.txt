GazeTrain
---------

Table of Contents:

1. What is GazeTrain?
1.1 Minimum Requirements
2. Customization (Eye Tracker)
3. Help out
4. Todo List
5. License

1. What is GazeTrain?
---------------------
GazeTrain is a gaze-controlled action/puzzle game. In the game, you must guide a train by placing track tiles in front of it. As you guide the train, you must collect various cargo and drop them off at the nearest city thereby earning money. For further details regarding how to play the game, we encourage you to read the tutorial accessible from the main menu.

1.1 Minimum Requirements
------------------------

The following are the minimum requirements for running GazeTrain:

Operating System: Windows 2000, Windows XP, Windows Vista or Windows 7
Software: DirectX 8 or later
Graphics Card: DirectX 8 compatible graphics card with at least 32MB of video memory
Processor: Pentium or equivalent processor
Sound Card: DirectX 8 compatible sound card
Memory (RAM): 128 MB of memory or greater
Resolution: 800�600 or greater screen resolution with 16-bit or 32-bit colors
Eye-Tracker: Any tracker capable of emulating mouse movements. A regular mouse can also be used.

Note that the playability of GazeTrain will vary significantly depending on the resolution and associated display size, as well as the display presented by the eye-tracker software. Therefore, we recommend playing GazeTrain on a large display.


2. Customization
----------------

One of the key features of GazeTrain is its accessability. There is a number of settings which can be adjusted to better suit your play style in the INI files that the game creates:

2.1 The 'config.ini' File
-------------------------

This file is created when you first enter the options menu and exit it. Once created, the file and it's settings will be used the next time the game is started. A number of the settings found in the ini file can be changed inside the game (in the options menu). But a number of advanced settings can only be changed by directly editing the ini file. All of these settings (described below) are used to manipulate the dwell time used in GazeTrain:

2.1.1 TimeUntilInView
---------------------

This setting defines how many seconds should pass before the game registers an elements as being "in-view". Elements which are in-view (and selectable) have yellow corner borders shown around them. This setting is initially set to zero seconds.

2.1.2 TimeUntilSelected
-----------------------

This setting defines how many seconds it should take for an element, which is not a button or a tile, to be selected. However, it is currently a redundant setting since all currently selectable tiles are either buttons or tiles.

2.1.3 TimeUntilSelectedButton
-----------------------------

This setting defines the dwell time until a button is selected.

2.1.4 TimeUntilSelectedTile
---------------------------

This setting defines the dwell time until a tile is selected.

2.2 The 'difficulty.ini' File
-----------------------------

This file is created after a single game has been finished. However, it should be noted that only settings for the games have been played are written to the file. Therefore, if you intend to alter the setting for the Timed mode, conductor setting, you must select that game mode and play it, then quite if you wish. Then the settings will be available to change in the difficulty.ini file.

Most of the settings are straightforward, but they are listed below for the sake of clarity. All of the settings relate to a specific game mode (and possibly difficulty setting).

2.2.1 trainTimeUntilDeparture
-----------------------------

This setting defines the delay until the train departs from its original starting position.

2.2.2 trainInitialSpeed
-----------------------

This setting defines the initial speed of the train.

2.2.3 trainMaxSpeed
-------------------

This setting defines the absolute maxiumum speed the train.

2.2.4 trainAcceleration
-----------------------

This setting defines how much of a speed increase the train recieves when it accelerates.

2.2.5 ticksBetweenAcceleration
------------------------------

This setting defines the number of ticks between acceleration. If the game is on its default setting, there are a total of 30 ticks per second. So a value of 30 would mean that the train would accelerate every second. A setting of 60 would mean that the train would accelerate every second second. etc.

3. Help out
-----------

GazeTrain was developed with the support of the Technical University of Denmark and the network of Excellence. If you would like support the future development of this (and other) gaze-controlled games, there are a number of things you can do!


3.1 Provide Feedback
--------------------

If you have played the game, please tell us what you think about it! Did you enjoy it, or was there something that you disliked? What would you like to change? Please send any feedback to the following E-Mail address:

					gazetrain@cogain.org

3.2 Participate in development
------------------------------

The source for GazeTrain is freely available for download and further development. GazeTrain was developed using Game Maker 7.0 Pro, which you will require if you wish to improve the game. Since GazeTrain is licensed under the GPL license, you are free to make any changes and release your own version, as long as it is also released under the GPL license. The source for GazeTrain can be downloaded from the following URL:

		http://www.cogain.org/downloads/leisure-applications/gazetrain/

If you'd like some inspiration as to what could be improved upon, have a look at the "todo list" included in this readme in section 4.


3.3 Donate
----------

Another way to contribute is to donate a small amount of money towards further development. If you wish to donate towards further development, please visit this URL, and click on the donate button at the bottom:

		http://www.cogain.org/downloads/leisure-applications/gazetrain/


4. Todo List
------------

This list contains a number of ideal improvements that the game would benefit from:

* Music - currently, there is no musical score.
* Translation - the current release is "hard-coded" to english, but has
been slightly prepared for multi-lingual support.

The list is quite short, but it only lists items that have not been implemented in any shape or form. Any of the allready existing features are also ideal to expand upon, ranging from the game mechanics to the interface.

5. License
----------
GazeTrain: A gaze-controlled action/puzzle game.
Copyright (C) 2009  Lasse Farnung Laursen (for the Technical University of Denmark)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

