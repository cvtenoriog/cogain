This is the Source release of GazeTrain. As described on the www.cogain.org homepage, you must own a copy of Game Maker PRO in order to edit the source.

The entire source and associated assets (except for specific assets detailed in the credits section of the game) are Copyright to Lasse Farnung Laursen, 2009 and are licensed under the GNU GENERAL PUBLIC LICENSE included in the zip.